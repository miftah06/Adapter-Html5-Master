﻿{
	"version": 1585810220,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"c2webappstart.js",
		"images/sprite-sheet0.png",
		"images/sprite2-sheet0.png",
		"images/sprite3-sheet0.png",
		"images/sprite4-sheet0.png",
		"images/sprite5-sheet0.png",
		"images/sprite5-sheet1.png",
		"images/sprite6-sheet0.png",
		"images/sprite7-sheet0.png",
		"images/sprite8-sheet0.png",
		"images/spritefont.png",
		"media/die.ogg",
		"media/hit.ogg",
		"media/point.ogg",
		"media/swoosh.ogg",
		"media/wing.ogg"
	]
}